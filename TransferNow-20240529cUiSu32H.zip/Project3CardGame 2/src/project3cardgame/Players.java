package project3cardgame;

import java.util.Objects;

/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * <pre>
 * File			City.java
 * Description          A class representing a large USA city with 5 properties:
 * name, age ( in millions), money income, percent
 * native born, and percent with advanced degree.
 * Project              Large USA Cities Database
 * Platform		jdk 20_0_1, NetBeans IDE 19,  Windows 10
 * Course		CS 142 ON1, Fall 2022, Edmonds College
 * @author		<i>Quynh</i>
 * @version %1% %5% Hours	1 hours and 45 mins. Date	9/20/2023 21/9/2023 History
 * Log
 * </pre>
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

public class Players extends Person implements Comparable<Players> {

    //essential features that our city would have
    private String name;
    private int age;
    private double money;

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     *        Constructor     City()-default constructor
     *        Description     Create an instance of the city class and assign
     *                        default values to all fields.
     *        @author         <i>Quynh</i>
     * Date 20/9/2023 History log 20/9/2023 21/9/2023
     * </pre>
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    public Players() //default and overflow constr for the class.
    //Doesn't need to have every getter and setter, it can change (setter)
    {
        name = "";
        age = 0;
        money = 0;

    }
    

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor     City()-overloaded constructor
     * Description     Create an instance of the Name class and assign values
     * via parameters to all fields.
     *        @author         <i>Quynh</i>
     * @param Name String
     * @param age float
     * @param dollars float
     * Date 20/9/2023 
     * History log 20/9/2023 21/9/2023
     * </pre>
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    public Players(String Name, int age, double dollars) {
        name = Name;
        this.age = age;
        this.money = dollars;

    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     *        Constructor     City()-overloaded copy constructor
     *        Description     Create an instance of the city class and assign values
     *                        via parameters to all fields.
     *        @author         <i>Quynh</i>
     * @param anotherPlayers City Date 20/9/2023 History log 20/9/2023 21/9/2023
     * </pre>
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    public Players(Players anotherPlayers) {
        name = anotherPlayers.name;
        age = anotherPlayers.age;
        this.money = anotherPlayers.money;

    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public void setAge(int age) {
        this.age = age;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     *        Method           toString()
     *        Description      Overridden toString() method to display a City object
     *        @author          <i>Quynh</i>
     * @return City object String Date 20/9/2023 History log 20/9/2023 21/9/2023
     * </pre>
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    @Override
    public String toString() {
        return " Name: " + name + "\nAge: " + age
                + "\nMoney: " + money;
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     *    Method          equals()
     *    Description     Own method to check if one City object equals to another
     *    @author         <i>Quynh</i>
     * @param city City
     * @return true or false boolean Date 20/9/2023 History log 20/9/2023
     * 21/9/2023
     * </pre>
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
        return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
        return false;
    }
    Players otherPlayer = (Players) obj;
    return Objects.equals(this.getName(), otherPlayer.getName());
//        Players city = new Players();
//        if (obj instanceof Players) {
//            city = (Players) obj;
//            if (this.getName().equalsIgnoreCase(city.getName())
//                    && (closeEnough(this.getAge(), city.getMoney()))) {
//                return true;
//            } else {
//                return false;
           // }
//           else {
//            return false;
//        }
        } 
    

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     *    Method          closeEnough()
     *    Description     Method to check if two floating numbers are within EPISON
     *                    of each other.Used of comparison of floating point values.
     *    @author         <i>Quynh</i>
     * @param x float
     * @param y float
     * @return true or false boolean Date 20/9/2023 History log 20/9/2023
     * 21/9/2023
     * </pre>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private boolean closeEnough(double x, double y) {
        final double EPSILON = 1E-9; //can increase the accurate, higher can.
        return Math.abs(x - y) < EPSILON;
    }
     @Override
    public int compareTo(Players other) {
        // Define your comparison logic here
        // For example, compare based on age
        return Integer.compare(this.age, other.age);
    }
    @Override
    public int hashCode() {
        //return Objects.hash(name);
        return Objects.hash(name, age, money);
    }
     public Players(String name) {
        this.name = name;
    }
}
