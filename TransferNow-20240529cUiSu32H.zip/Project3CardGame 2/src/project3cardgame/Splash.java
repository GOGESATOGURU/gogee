
package project3cardgame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.BorderFactory;
import javax.swing.JWindow;
import javax.swing.UIManager;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    * Splash.java
    * A class representing the Splash screen used by the Cities.java
    * GUI used in a maintaining a USA cities database
    * <pre>
    *Project    Cities Database 
    *Platform   jdk 1.6.0_14; NetBeans IDE 19; Windows 10
    *Course     CS 142
    *Hours      1 hours and 45 minutes
    *Date       9/28/2023
    *History Log September 28, 2023, 11: 09: 01 PM
    *</pre>
    * @author       <i>Quynh Le</i>
    * @version      %1% %2%
    * @see         java.awt.Color
    * @see         java.awt.Toolkit
    * @see         javax.BorderFactory
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class Splash extends JWindow
{
    private int duration;
    JProgressBar loading = null;  
    //progress bar
    private int progress; 
    public Splash (int dur)
    {
        duration = dur;
        UIManager.put("ProgressBar.selectionBackground", Color.black);
        UIManager.put("ProgressBar.selectionForeground", Color.white);
        UIManager.put("ProgressBar.foreground", new Color (58, 3, 128));
        //color not working. 
        loading = new JProgressBar(0,100);
        loading.setStringPainted(true);
    }
    public void showSplash()
    {
        JPanel content = (JPanel)getContentPane();
        content.setBackground(Color.lightGray);
        
        int width = 580;
        int height = 605;
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screen.width - width)/2;
        int y = (screen.height - height)/2;
        setBounds(x,y,width,height);
        
        //Build the splash screen
        JLabel label = new JLabel(new ImageIcon("src/images/give.jpg"));
        JLabel copyrt = new JLabel
         ("Copyright Large Cities USA Inc., 2023, Large USA Cities DataBbase", JLabel.CENTER);
        copyrt.setFont(new Font("Sans-Serif", Font.BOLD,12));
        //Set the font and stuff for the things
        
       content.add(label, BorderLayout.CENTER);
//       content.add(copyrt, BorderLayout.SOUTH);
       Color border = new Color(50, 20, 220, 55);
       content.add(loading, BorderLayout.SOUTH); 
       //adding the progress bar into the frame. loading is bar obj name, 
       //color set rgb.
       content.setBorder(BorderFactory.createLineBorder(border,10));
       
       //when everything is almost finis then make it visible
       setVisible(true);
       
       try
       {
              incProgress(20);
              Thread.sleep(duration);
              //set how many the duration is.
       }
       catch (Exception e)
       {
           e.printStackTrace();
       }
       setVisible(false);
       //set invisible after it visible. 
    }
     /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        incProgress()
    * Description   Nested class to add the loading bar to the program.
    * @param        amount int
    * @author       <i>Quynh Le</i>
    * Date          9/29/23
    * History Log   9/29/23  
    *</pre>
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void incProgress( int amount) throws InterruptedException
              //nested class really interesting
    {
        ProgressThread up = new ProgressThread(amount);
        up.thread.start();
    }
        class ProgressThread
        {
            private int amount;
            public ProgressThread(int amount)
            {
                this.amount = amount;
            }
            
            private Thread thread = new Thread (new Runnable()
            {
                @Override
                public void run()
                {
                    //Increment the progress bar until it's values hit 100%
                    while ( progress < 100)
                    {
                        progress++; //increase until hit 100. 
                        try
                        {
                            Thread.sleep(25); 
                        //sleep
                        }
                        catch ( InterruptedException ex)
                        {
                            
                        }
                        loading.setValue(progress);
                    }
                }
            });
}
}
  

            
