package project3cardgame;

import java.util.Objects;

public abstract class Person {

   protected String name;
   protected int age;
   public Person ()
   {
       this("", 0);
   }
   
   //default animal Constrcutor
   
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public Person (Person anotherAnimal)
    {
        name = anotherAnimal.name;
        age = anotherAnimal.age;
    }
    public Person (String name, int age)
    {
        this.name = name;
        this.age = age;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.name);
        hash = 79 * hash + this.age;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (this.age != other.age) {
            return false;
        }
        return Objects.equals(this.name, other.name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
}
