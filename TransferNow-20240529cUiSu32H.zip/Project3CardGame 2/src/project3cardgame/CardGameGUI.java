package project3cardgame;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import static java.lang.Math.random;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * <pre>
 * Class        CardGameGUI.java
 * Project      Large USA Cities Database
 * Description  A class representing the GUI used in a maintaining a cities
 * database obtained from a text file, Cities.txt with 5 fields:
 * name, population in millions, median income, percent of native
 * born, and percent of advanced degrees. Functionalities include:
 * viewing of the data for selected city, add, delete, edit, sort
 * by population and by name, and search for cpecified city.
 * File         CardGameGUI.java
 * Platform     jdk 1.8.0_214; NetBeans IDE 11.3; Windows 10
 * Course       CS 142, Edmonds Community College
 * Hours        12 hours and 45 minutes
 * Date         20/9/2023
 * History log  20/9/2023, 21/9/2023, 22/9/2023
 * @author	<i>Quynh</i>
 * @version %1% %2%
 * @see javax.swing.JFrame
 * @see java.awt.Toolkit
 * @see java.util.ArrayList
 * </pre>
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
public class CardGameGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private TreeSet<Players> Play_it = new TreeSet<>();
    DeckOfCards myDeck = new DeckOfCards();

    //external file name for cities
    private String filename = "src/project3cardgame/player.txt";
    private StringBuilder output = new StringBuilder();
    private Random myrandom = new Random();
    private DecimalFormat dollars = new DecimalFormat("$0.00");
    private final double ODDS_SAME_SUIT = 3;
    private final double ODDS_BOTH_FACE = 20;
    private final double ODDS_SAME_CARD = 16;
    private final double ODDS_SAME_FACE = 70;
    private final int NUM_CARDS = 2;
    private int[] cards = new int[NUM_CARDS];
    private int[] cardValue = new int[NUM_CARDS];
    private String names = "";
    private final int MAX_CAN_BET = 1000;

    private static CardGameGUI flagQuiz;
    private TreeSet<Players> currentSelected = new TreeSet<>();
    public String betAmount = "";
    private double betMoney = 0;
    private Clip clip;
    //  private ArrayList <> 
    // private JList<String> playerJList = new JList<>();

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor     CitiesGUI()-default constructor
     * Description     Create an instance of the CityGUI class
     * @author         <i>Quynh</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *
     * @throws java.io.IOException
     */
    public CardGameGUI() throws IOException {//throws IOException {
        initComponents(); //build the form. 
        this.getRootPane().setDefaultButton(exitJButton); //set addJButton as default
        this.setIconImage(Toolkit.getDefaultToolkit().
                getImage("src/project3cardgame/_.jpg"));
        this.setTitle("Card Play Game");
        setLocationRelativeTo(null);
        readFromFile(filename);
        displayPlayers();
        int index = playerJList.getSelectedIndex();
        if (index >= 0) {
            showCityData(playerJList.getSelectedIndex());
            // playBackgroundMusic();

        }
    }

    private void playBackgroundMusic() {
        String audioFilePath = "src/project3cardgame/ciaga.wav";

        try {
            File musicFile = new File(audioFilePath);

            if (!musicFile.exists()) {
                System.err.println("Audio file not found: " + audioFilePath);
                return;
            }

            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(musicFile);
            clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       readFromFile
     * Description  Reads cities from a text file that is comma delimited and
     *              creates an instance of the City class with the data read.
     *              Then the newly created city is added to the cities database.
     *              Uses an object from the ReadFile class to read record.
     * @author      <i>Quynh</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * @param file String
     * @see java.util.Scanner
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void readFromFile(String file) throws IOException {
        Play_it.clear();
        playerJList.removeAll();

        try {
            FileReader inputFile = new FileReader(file);
            BufferedReader input = new BufferedReader(inputFile);

            String line = "";
            while ((line = input.readLine()) != null) {
                StringTokenizer token = new StringTokenizer(line, ",");

                Players play = new Players(); // Default constructor to create a player
                if (token.countTokens() > 0) { // Ensure there are three tokens (name, age, money)
                    play.setName(token.nextToken().trim());
                    play.setAge(Integer.parseInt(token.nextToken().trim()));
                    play.setMoney(Double.parseDouble(token.nextToken()));
                    Play_it.add(play);

                } else {
                    System.out.println("Skipping invalid line: " + line);
                }
            }

            inputFile.close();
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, " does not exist",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
            //Bring up the JFileChooser to select file in current directory
            JFileChooser chooser = new JFileChooser("src/USACities");
            FileNameExtensionFilter filter = new FileNameExtensionFilter(
                    "Txt Files", "txt");
            chooser.setFileFilter(filter);
            int choice = chooser.showOpenDialog(null);
            if (choice == JFileChooser.APPROVE_OPTION) {
                File chosenFile = chooser.getSelectedFile();
                file = "src/project3cardgame/" + chosenFile.getName();
                //System.out.println("file = " + file);
                readFromFile(file);
            }
        }

    }
//        Play_it.clear();
//    playerJList.removeAll();
//
//    try 
//        {
//            FileReader inputFile = new FileReader(file);
//            BufferedReader input = new BufferedReader(inputFile); 
//
//        String line = "";
//        while ((line = input.readLine()) != null) {
//            StringTokenizer token = new StringTokenizer(line, ",");
//            
//            Players play = new Players(); // Default constructor to create a player
//            if (token.countTokens() > 0) { // Ensure there are three tokens (name, age, money)
//               // Players play = new Players();
//                play.setName(token.nextToken().trim());
//                play.setAge(Integer.parseInt(token.nextToken().trim()));
//                play.setMoney(Double.parseDouble(token.nextToken().trim()));
//                Play_it.add(play);
//                System.out.println("\t Play it : " + Play_it);
//
//            // Read the file, stopping at the comma
////            while (token.hasMoreElements()) {
////                // Read every token and ASSIGN IT to the player object
////                play.setName(token.nextToken());
////                play.setAge(Integer.parseInt(token.nextToken()));
//////                play.setMoney(Double.parseDouble(token.nextToken()));
////                String moneyToken = token.nextToken();
////                System.out.println("Money Token: " + moneyToken);
////                play.setMoney(Double.parseDouble(moneyToken));
//                System.out.println(play.getName());
////                Play_it.add(play);
//            }
//             else {
//                System.out.println("Skipping invalid line: " + line);
//            }
//
//            
//        }
//   
//        
//        
//
//        } catch (FileNotFoundException e) {
//            JOptionPane.showMessageDialog(null, " does not exist",
//                    "File Input Error", JOptionPane.WARNING_MESSAGE);
//            //Bring up the JFileChooser to select file in current directory
//            JFileChooser chooser = new JFileChooser("src/USACities");
//            FileNameExtensionFilter filter = new FileNameExtensionFilter(
//                    "Txt Files", "txt");
//            chooser.setFileFilter(filter);
//            int choice = chooser.showOpenDialog(null);
//            if (choice == JFileChooser.APPROVE_OPTION) {
//                File chosenFile = chooser.getSelectedFile();
//                file = "src/project3cardgame/" + chosenFile.getName();
//                //System.out.println("file = " + file);
//                readFromFile(file);
//            }
//
//        }
//
//    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       displayPlayers()
     * Description  Displays cities in JList sorted by level = 0 using
     * selection sort algorithm or last name = 1 using the
     * insertion sort algorithm.
     * @author      <i>Quynh</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * @see #selectionSort
     * @see #insetionSort
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
//    @SuppressWarning({"checked", "unchecked"})
    private void displayPlayers() {
        int location = playerJList.getSelectedIndex();
        int index = 0;
        String[] playersNames = new String[Play_it.size()]; // array with names only

        // iterate through the TreeSet to create array of names only
        Iterator<Players> iterator = Play_it.iterator();
        while (iterator.hasNext() && index < Play_it.size()) {
            Players aPlayer = iterator.next();
            playersNames[index++] = aPlayer.getName();
        }

        playerJList.setListData(playersNames);

        // Optionally, restore the selected index
        if (location >= 0 && location < Play_it.size()) {
            playerJList.setSelectedIndex(location);
        }

//      int location = playerJList.getSelectedIndex();
//        int index = 0;
//        String[] playersNames = new String[Play_it.size()]; // array with names only
//
//        // iterate through the TreeSet to create array of names only
//        Iterator<Players> iterator = Play_it.iterator();
//        while (iterator.hasNext() && index < Play_it.size()) 
//        {
//            Players aPlayer = iterator.next();
//            playersNames[index++] = aPlayer.getName();
//            
//        }
//           playerJList.setListData(playersNames);
//
//            // Optionally, restore the selected index
//            if (location >= 0 && location < Play_it.size()) 
//            {
//                playerJList.setSelectedIndex(location);
//            } 
    }

    //fix this code a little 
//        int location = playerJList.getSelectedIndex(); // find the index of 
//        //which cities we wants to display
//        String[] playerList = new String[Play_it.size()]; //array with name only
//
//        playerJList.setListData(playerList); //populate the Jlist w city
//        if (location < 0) {
//            playerJList.setSelectedIndex(0); //select first city
//        } else {
//            playerJList.setSelectedIndex(location);
//        }
    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       insertionSort
     * Description  Sorts ArrayList cities in ascending order by name. Uses
     *              the insertion sort algorithm which inserts city at correct
     *              position and shuffles everyone else below that position.
     * @param       cities ArrayList
     * @author      <i>Quynh</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
//    public static void insertionSort(TreeSet<Players> cities)
//            //Algorithms nested loops that go and compare each with others
//            //moving one by one
//            
//      //More efficient if the array are already sort, less if you do a lot
//      //of swap or comparision, no bueno. It good if you do some comparison
//      //it's like go through each time and swap place each time. 
//    {
//        int i, j;
//        for(i = 0; i < cities.size(); i++)
//        {
//            Players temp = cities.get(i); //creating temporary city at i
//            j= i-1;
//            //comapre if they're bigger, which one is bigger. 
//          while( j >= 0 && cities.get(j).getName().compareToIgnoreCase(temp.getName())>0)
//              //greater than (alphabetically) return positive one, 
//            {
//                cities.set(j+1, cities.get(j));
//                //if it's greater then move it. 
//                //small to the largest, according to the alphabet.
//                j--;
//            }
//            cities.set(j+1, temp);
//        }
//    }
    public static void insertionSort(TreeSet<Players> cities) {
        Iterator<Players> iterator = cities.iterator();
        Players[] playersArray = new Players[cities.size()];

        // Copy elements from TreeSet to an array
        int index = 0;
        while (iterator.hasNext()) {
            playersArray[index] = iterator.next();
            index++;
        }

        // Perform insertion sort on the array
        int i, j;
        for (i = 1; i < playersArray.length; i++) {
            Players temp = playersArray[i];
            j = i - 1;
            while (j >= 0 && playersArray[j].getName().compareToIgnoreCase(temp.getName()) > 0) {
                playersArray[j + 1] = playersArray[j];
                j--;
            }
            playersArray[j + 1] = temp;
        }

        // Clear the original TreeSet and add elements back from the sorted array
        cities.clear();
        for (Players player : playersArray) {
            cities.add(player);
        }
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       selectionSort
     * Description  Sorts ArrayList cities in descending order by population.
     *              Calls findsMaximum to find city with maximum population in
     *              each pass and swap to exchange cities when necessary.
     * @param       cities ArrayList
     * @author      <i>Quynh</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
//    public void selectionSort(ArrayList <City> cities)
//            //passing the whole array list to it
//            //go through and find the smallest, lots of compare and switch one at the end
//            //the smallest in an array, benefitical if it's large comparision. 
//    {
//    int max = 0;
//    for(int i = 0; i < cities.size(); i++)
//    {
//        max = findMaximum(cities, i); //find the largest population. 
//        //swap (cities, i, max)
//        City temp = cities.get(i); //same process, pass on 1st ->2, so on. 
//        cities.set(i,cities.get(max));
//        cities.set(max, temp);
//        //Once we found the city with the largest population, we going to 
//        //swap it with the first position. 
//    }
//}
    public void selectionSort(TreeSet<Players> cities) {
        Iterator<Players> iterator = cities.iterator();
        Players[] citiesArray = new Players[cities.size()];

        // Copy elements from TreeSet to an array
        int index = 0;
        while (iterator.hasNext()) {
            citiesArray[index] = iterator.next();
            index++;
        }

        int max;
        for (int i = 0; i < citiesArray.length; i++) {
            max = findMaximum(citiesArray, i); // find the city with the largest population
            // Swap cities
            Players temp = citiesArray[i];
            citiesArray[i] = citiesArray[max];
            citiesArray[max] = temp;
        }

        // Clear the original TreeSet and add elements back from the sorted array
        cities.clear();
        for (Players city : citiesArray) {
            cities.add(city);
        }
    }

    private int findMaximum(Players[] cities, int start) {
        int maxIndex = start;
        for (int i = start + 1; i < cities.length; i++) {
            if (cities[i].getAge() > cities[maxIndex].getMoney()) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       findMaximum
     * Description  Called by selectionSort to find the index of the member
     *              with the maximum population from a given index to the end
     *              of the ArrayList
     * @param       cities ArrayList
     * @param i int
     * @return int
     * @author      <i>Quynh</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sortButtonGroup = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        titleJPanel = new javax.swing.JPanel();
        titleJLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        betJTextField = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        playerJList = new javax.swing.JList<>();
        exitJButton = new javax.swing.JButton();
        playerTittleJLabel = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        instructorJTextArea = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        card1JLabel = new javax.swing.JLabel();
        card2JLabel = new javax.swing.JLabel();
        drawCardJButton = new javax.swing.JButton();
        clearJButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        stopMusicJButton = new javax.swing.JButton();
        pMusicJButton = new javax.swing.JButton();
        resultJTextAreaS = new javax.swing.JScrollPane();
        resultJTextArea = new javax.swing.JTextArea();
        cardJMenuBar = new javax.swing.JMenuBar();
        fileJMenu = new javax.swing.JMenu();
        fileJSeparator = new javax.swing.JPopupMenu.Separator();
        exitJMenuItem = new javax.swing.JMenuItem();
        savePlayerJMenuItem = new javax.swing.JMenuItem();
        printPlayerJMenuItem = new javax.swing.JMenuItem();
        printPlayerFormJMenuItem = new javax.swing.JMenuItem();
        newJMenuItem = new javax.swing.JMenuItem();
        actionJMendatabaseJMenuu = new javax.swing.JMenu();
        deleteJMenuItem = new javax.swing.JMenuItem();
        searchJMenuItem = new javax.swing.JMenuItem();
        addJMenuItem = new javax.swing.JMenuItem();
        helpJMenu = new javax.swing.JMenu();
        aboutJMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Large USA Cities Statistics");
        setBackground(new java.awt.Color(165, 170, 210));
        setResizable(false);

        titleJLabel.setFont(new java.awt.Font("Constantia", 2, 24)); // NOI18N
        titleJLabel.setForeground(new java.awt.Color(51, 0, 0));
        titleJLabel.setText("Welcome to Black Jack ");

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        jLabel1.setText("What is your bet: ");

        betJTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                betJTextFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout titleJPanelLayout = new javax.swing.GroupLayout(titleJPanel);
        titleJPanel.setLayout(titleJPanelLayout);
        titleJPanelLayout.setHorizontalGroup(
            titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titleJPanelLayout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(titleJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(356, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, titleJPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(betJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        titleJPanelLayout.setVerticalGroup(
            titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, titleJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titleJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                .addContainerGap(23, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, titleJPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(betJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)))
        );

        playerJList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                playerJListValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(playerJList);

        exitJButton.setBackground(new java.awt.Color(192, 225, 227));
        exitJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitJButton.setMnemonic('x');
        exitJButton.setText("Exit");
        exitJButton.setToolTipText("Exit application");
        exitJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitJButtonActionPerformed(evt);
            }
        });

        playerTittleJLabel.setFont(new java.awt.Font("Helvetica Neue", 3, 18)); // NOI18N
        playerTittleJLabel.setText("Players");

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 3, 18)); // NOI18N
        jLabel2.setText("Results: ");

        instructorJTextArea.setColumns(20);
        instructorJTextArea.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        instructorJTextArea.setRows(5);
        instructorJTextArea.setText("Welcome to the Black Jack The rules is that the dealer going to give \nyou 2 card that revealed for you. The dealer going to reveal one of\n their card, you can go first and then the dealer's turn. You won if \nyou got five card charlie, not busted while your number is greater than \nthe dealer or you got Black Jack. Same for dealer, enter hit to keep draw card\nwhile enter Stand if you want to Stop");
        instructorJTextArea.setToolTipText("");
        instructorJTextArea.setWrapStyleWord(true);
        jScrollPane3.setViewportView(instructorJTextArea);

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        jLabel3.setText("Instructors: ");

        card1JLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/10.png"))); // NOI18N
        card1JLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        card2JLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/15.png"))); // NOI18N
        card2JLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        drawCardJButton.setFont(new java.awt.Font("Helvetica Neue", 3, 18)); // NOI18N
        drawCardJButton.setText("Draw card");
        drawCardJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drawCardJButtonActionPerformed(evt);
            }
        });

        clearJButton.setFont(new java.awt.Font("Helvetica Neue", 3, 18)); // NOI18N
        clearJButton.setText("Clear");
        clearJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearJButtonActionPerformed(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project3cardgame/small0.png"))); // NOI18N
        jLabel6.setToolTipText("");

        stopMusicJButton.setBackground(new java.awt.Color(192, 225, 227));
        stopMusicJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        stopMusicJButton.setMnemonic('x');
        stopMusicJButton.setText("Stop Music");
        stopMusicJButton.setToolTipText("Exit application");
        stopMusicJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopMusicJButtonActionPerformed(evt);
            }
        });

        pMusicJButton.setBackground(new java.awt.Color(192, 225, 227));
        pMusicJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        pMusicJButton.setMnemonic('x');
        pMusicJButton.setText("Play Music");
        pMusicJButton.setToolTipText("Exit application");
        pMusicJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pMusicJButtonActionPerformed(evt);
            }
        });

        resultJTextArea.setColumns(20);
        resultJTextArea.setRows(5);
        resultJTextArea.setWrapStyleWord(true);
        resultJTextAreaS.setViewportView(resultJTextArea);

        fileJMenu.setMnemonic('F');
        fileJMenu.setText("File");
        fileJMenu.add(fileJSeparator);

        exitJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        exitJMenuItem.setMnemonic('x');
        exitJMenuItem.setText("Exit");
        exitJMenuItem.setToolTipText("");
        exitJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(exitJMenuItem);

        savePlayerJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ENTER, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        savePlayerJMenuItem.setMnemonic('y');
        savePlayerJMenuItem.setText("Save Player");
        savePlayerJMenuItem.setToolTipText("Print city data");
        savePlayerJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savePlayerJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(savePlayerJMenuItem);

        printPlayerJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ENTER, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        printPlayerJMenuItem.setMnemonic('y');
        printPlayerJMenuItem.setText("Print Result");
        printPlayerJMenuItem.setToolTipText("Print city data");
        printPlayerJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printPlayerJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(printPlayerJMenuItem);

        printPlayerFormJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ENTER, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        printPlayerFormJMenuItem.setMnemonic('y');
        printPlayerFormJMenuItem.setText("Print Form");
        printPlayerFormJMenuItem.setToolTipText("Print city data");
        printPlayerFormJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printPlayerFormJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(printPlayerFormJMenuItem);

        newJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ENTER, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        newJMenuItem.setMnemonic('N');
        newJMenuItem.setText("New Player");
        newJMenuItem.setToolTipText("New City DB");
        newJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(newJMenuItem);

        cardJMenuBar.add(fileJMenu);

        actionJMendatabaseJMenuu.setMnemonic('t');
        actionJMendatabaseJMenuu.setText("Players DataBase");

        deleteJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_PAGE_UP, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        deleteJMenuItem.setMnemonic('D');
        deleteJMenuItem.setText("Delete Player");
        deleteJMenuItem.setToolTipText("Delete");
        deleteJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteJMenuItemActionPerformed(evt);
            }
        });
        actionJMendatabaseJMenuu.add(deleteJMenuItem);

        searchJMenuItem.setMnemonic('r');
        searchJMenuItem.setText("Search Player");
        searchJMenuItem.setToolTipText("Search");
        searchJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchJMenuItemActionPerformed(evt);
            }
        });
        actionJMendatabaseJMenuu.add(searchJMenuItem);

        addJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_PAGE_UP, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        addJMenuItem.setMnemonic('D');
        addJMenuItem.setText("Add Player");
        addJMenuItem.setToolTipText("Delete");
        addJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJMenuItemActionPerformed(evt);
            }
        });
        actionJMendatabaseJMenuu.add(addJMenuItem);

        cardJMenuBar.add(actionJMendatabaseJMenuu);

        helpJMenu.setMnemonic('H');
        helpJMenu.setText("Help");

        aboutJMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_TAB, java.awt.event.InputEvent.ALT_DOWN_MASK));
        aboutJMenuItem.setMnemonic('A');
        aboutJMenuItem.setText("About");
        aboutJMenuItem.setToolTipText("About the program");
        aboutJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutJMenuItemActionPerformed(evt);
            }
        });
        helpJMenu.add(aboutJMenuItem);

        cardJMenuBar.add(helpJMenu);

        setJMenuBar(cardJMenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(clearJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(205, 205, 205)
                        .addComponent(drawCardJButton))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(card1JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(73, 73, 73)
                        .addComponent(card2JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel3))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(exitJButton)
                        .addGap(90, 90, 90)
                        .addComponent(stopMusicJButton)
                        .addGap(101, 101, 101)
                        .addComponent(pMusicJButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(playerTittleJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(resultJTextAreaS, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(titleJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titleJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(card1JLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(card2JLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(drawCardJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(clearJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(playerTittleJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(resultJTextAreaS, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exitJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stopMusicJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pMusicJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method        exitJButtonActionPerformed()
     * Description   Event handler to close the application
     * @param        evt ActionWvent
     * @see java.awt.event.ActionEvent
     * @author       <i>Quynh</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void exitJButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitJButtonActionPerformed
    {//GEN-HEADEREND:event_exitJButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitJButtonActionPerformed

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          aboutJMenuItemActionPerformed()
     * Description     Even handler for aboutJMenuItem to show the About form
     * @param          evt ActionEvent
     * @author         <i>Quynh</i>
     * Date 9/28/23 History Log 9/28/23
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void aboutJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutJMenuItemActionPerformed
        About aboutWindow = new About(this, true);
        //calling object, 
        aboutWindow.setVisible(true);
        //make "about form" show on the main form when click help.
        //You can change the 2nd true to false, when it set to false then you can
        //click on the main display form. When = true, can't touch the main form.
    }//GEN-LAST:event_aboutJMenuItemActionPerformed
    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          deleteJMenuItemActionPerformed()
     * Description     Even handler for addMenuItem to invoke the deleteJMenuItem
     * @param          evt ActionEvent
     * @author         <i>Quynh</i>
     * Date 2/10/23 History Log
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void deleteJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteJMenuItemActionPerformed
        String selectedPlayer = playerJList.getSelectedValue();

        if (selectedPlayer == null) {
            JOptionPane.showMessageDialog(null, "Please select a player to delete.",
                    "Delete Player", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int result = JOptionPane.showConfirmDialog(null,
                "Do you wish to delete " + selectedPlayer + "?", "Delete Player",
                JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);

        if (result == JOptionPane.YES_OPTION) {
            // Find and remove the player from the set
            Players playerToRemove = findPlayer(selectedPlayer);
            if (playerToRemove != null) {
                Play_it.remove(playerToRemove);
                readAndUpdateGUI();
                writeFile(filename);

                try {
                    // Read from the file to update your GUI or perform other actions
                    readFromFile(filename);
                } catch (IOException ex) {
                    Logger.getLogger(CardGameGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Player not found in the set.",
                        "Delete Player", JOptionPane.WARNING_MESSAGE);
            }
        }
        //error here NEED TO WORK ON

        // Check if a valid item is selected
//    if (index != -1) {
//        String name = Play_it.iterator().next().getName();  // Get the name from the TreeSet
//
//        // Confirm deletion
//        int result = JOptionPane.showConfirmDialog(null, 
//            "Are you sure you wish to delete the selected " + name + " city?", 
//            "Delete City", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
//
//        // If the user confirms deletion
//        if (result == JOptionPane.YES_OPTION) {
//            // Remove the selected item
//            Iterator<Players> iterator = Play_it.iterator();
//            for (int i = 0; i < index; i++) {
//                iterator.next();
//            }
//            iterator.remove();
//
//            // Redisplay the players
//            displayPlayers();
//
//            // Save the changes
//            writeFile(filename);
//        }
//    } else {
//        JOptionPane.showMessageDialog(null, "Please select a player to delete.", "Delete Player", JOptionPane.WARNING_MESSAGE);
//    }
    }//GEN-LAST:event_deleteJMenuItemActionPerformed

    private void readAndUpdateGUI() {
        try {
            // Read from the file to update your GUI or perform other actions
            readFromFile(filename);
        } catch (IOException ex) {
            Logger.getLogger(CardGameGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          searchJMenuItemActionPerformed()
     * Description     Even handler for searchJMenuItem. It calls searchCity
     *                 method
     * @param          evt ActionEvent
     * @author         <i>Quynh</i>
     * Date 3/10/23 History Log
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void searchJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchJMenuItemActionPerformed
        //find specific city, ask for which city u want
        String playerName = JOptionPane.showInputDialog("Enter name of the Player");
        findCity(playerName);
    }//GEN-LAST:event_searchJMenuItemActionPerformed

    private Players findPlayer(String playerName) {
        for (Players player : Play_it) {
            if (player.getName().equals(playerName)) {
                return player;
            }
        }
        return null; // Player not found
    }


    private void betJTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_betJTextFieldActionPerformed
        double currentBalance = 0;
      
        try {
            if (!Validation.isValidDollarAmount(betJTextField.getText(), MAX_CAN_BET)) {
                throw new NumberFormatException("Invalid input");
            }

            String findName = playerJList.getSelectedValue();
            System.out.println(findName); //print out the name, yes.
            if (findName != null) {
                for (Players playSub : Play_it) {
                    if (playSub.getName().equals(findName)) {
                        currentBalance = playSub.getMoney();
                        resultJTextArea.setText(playSub.toString());
                    }
                }
                //get the current balance yeee
                System.out.println("Current Balance: " + currentBalance);
                betMoney = currentBalance;
            }
            betAmount = betJTextField.getText();
            if (Validation.isValidDollarAmount(betAmount, currentBalance)) {
                betJTextField.setEnabled(true);
                betJTextField.requestFocus();
                //tell everything that you want this to be the main thing, take in user input. 

                newJMenuItem.setEnabled(true);
                addJMenuItem.setEnabled(true);
                aboutJMenuItem.setEnabled(true);
                searchJMenuItem.setEnabled(true);
                deleteJMenuItem.setEnabled(true);
                printPlayerJMenuItem.setEnabled(true);
                
            } else {
                betJTextField.requestFocus();
                betJTextField.setToolTipText("Invalid Bet, your bet have to be something in player range. Please don't be delulu or put in Negative number.");
            }
            

            //displayDog();
        } catch (NumberFormatException exp) {
            String invalid = "Invalid, input must be in range of your bank roll";
            betJTextField.selectAll();
            JOptionPane.showMessageDialog(null, invalid, "Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_betJTextFieldActionPerformed
// private static int indexOf(TreeSet<Integer> set,
//                               Integer element)
//    {
// 
//        // Step 1: Convert TreeSet to ArrayList or
//        // LinkedList
//        //List<Integer> list = new ArrayList<>(set);
// 
//        // Step 2: Use the indexOf method of the List
//      //  return list.indexOf(element);
//    } Index of error

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method        exitJMenuItemActionPerformed()
     * Description   Call the exitJButtonActionPerformed event handler to exit
     * @param        evt ActionWvent
     * @see java.awt.event.ActionEvent
     * @author       <i>Quynh Le</i>
     * Date 9/22/2023 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void exitJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitJMenuItemActionPerformed
        exitJButtonActionPerformed(evt);
    }//GEN-LAST:event_exitJMenuItemActionPerformed

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method        printJMenuItem1ActionPerformed()
     * Description   Event handler for printJMenuItem1ActionPerformed to print the
     *               city as a data itself.
     * @param        evt ActionEvent
     * @author       <i>Quynh Le</i>
     * Date 9/27/2023 History Log 9/27/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void printPlayerJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printPlayerJMenuItemActionPerformed
        int index = playerJList.getSelectedIndex();
        if (index >= 0) {
            try {
                Iterator<Players> iterator = Play_it.iterator();
                int currentIndex = 0;

                // Find the selected player in the TreeSet
                Players selectedPlayer = null;
                while (iterator.hasNext() && currentIndex <= index) {
                    selectedPlayer = iterator.next();
                    currentIndex++;
                }

                if (selectedPlayer != null) {
                    // Now you can use selectedPlayer to access information and print it
                    String output = "Name: " + selectedPlayer.getName() + "\n"
                            + "Age: " + selectedPlayer.getAge() + "\n"
                            + "Money: " + dollars.format(selectedPlayer.getMoney());

                    System.out.println(output);

                    // If you want to display this information in a JTextArea, you can set the text
                    // yourJTextArea.setText(output);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error retrieving player information",
                        "Error", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            // Handle the case when no item is selected
            System.out.println("No player selected");
        }
    }//GEN-LAST:event_printPlayerJMenuItemActionPerformed

    private void playerJListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_playerJListValueChanged
        int index = (playerJList.getSelectedIndex());
        //grab the index that being highlighted from JList and 
        if (index >= 0)
            showCityData(index);
    }//GEN-LAST:event_playerJListValueChanged
    private void savePlayers(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(Play_it);
            System.out.println("Players saved successfully.");
        } catch (IOException e) {
            e.printStackTrace(); // Handle the exception based on your needs
        }
    }
    private void savePlayerJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savePlayerJMenuItemActionPerformed
// Get the text from resultJTextField
        String resultText = resultJTextArea.getText();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename, true))) {
            // Write the text to the file
            oos.writeObject(resultText);
            System.out.println("Text appended successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_savePlayerJMenuItemActionPerformed

    private void addJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addJMenuItemActionPerformed

        try {
            AddPlayer playerDialog = new AddPlayer();
            playerDialog.setVisible(true);

            Players newPlayer = playerDialog.getPlayers();

            if (newPlayer != null && !Play_it.contains(newPlayer)) {
                Play_it.add(newPlayer);
                writeFile(filename);
                displayPlayers();
                playerJList.setSelectedValue(newPlayer.getName(), true);

            }
        } catch (Exception e) {
            e.printStackTrace(); // Print the exception details to the console for debugging
            // Handle the exception or log it as needed
        }
    }//GEN-LAST:event_addJMenuItemActionPerformed

    private void printPlayerFormJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printPlayerFormJMenuItemActionPerformed
        PrintUtilities.printComponent(this);
    }//GEN-LAST:event_printPlayerFormJMenuItemActionPerformed

    private void newJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newJMenuItemActionPerformed
        JFileChooser chooser = new JFileChooser("src/project3cardgame");
        //chooser path of file located. 
        //filter only text file. 
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Txt Files", "txt");
        chooser.setFileFilter(filter);
        int choice = chooser.showOpenDialog(null);
        if (choice == JFileChooser.APPROVE_OPTION) //like yes I select this file. 
        {
            Play_it.clear();
            playerJList.removeAll();
            //remove and clear the current stuff in arraylist and Jlist

            File chosenFile = chooser.getSelectedFile();
            String file = "src/project3cardgame/" + chosenFile.getName();
            //to get the name
            filename = file;
            //your file name is a bit different compare to your teacher, it 
            //lower cases
            try {
                //System.out.println("file = " + file); debug purpose
                readFromFile(filename);
            } catch (IOException ex) {
                Logger.getLogger(CardGameGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
            displayPlayers(); //show file.
        } else {
            JOptionPane.showMessageDialog(null, "Unable to read file",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_newJMenuItemActionPerformed

    private void clearJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearJButtonActionPerformed
        playerJList.clearSelection();

    }//GEN-LAST:event_clearJButtonActionPerformed

    private void drawCardJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drawCardJButtonActionPerformed
        DeckOfCards numbers = new DeckOfCards();
        int currentIndex1 = numbers.getRandomCard();
        int currentIndex2 = numbers.getRandomCard();
        //TreeSet<Players> PlaySub = Play_it;
        double moneyWin = 0;
        String mon = betJTextField.getText();
        double doubleValue = Double.parseDouble(mon);
        String artPath1 = "src/images/" + currentIndex1 + ".png";
        card1JLabel.setIcon(new ImageIcon(artPath1));
        String artPath2 = "src/images/" + currentIndex2 + ".png";
        card2JLabel.setIcon(new ImageIcon(artPath2));
        

        String findName = playerJList.getSelectedValue();
        //get the selected user
        for (Players playSub : Play_it){
            double moneysub = playSub.getMoney();
//            // Check if the player name matches the selected user name
//            if (playSub.getName().equals(findName)) {
//                
//                if (currentIndex1 == currentIndex2) {
//                    // If the cards are equal, multiply money by 20
//                    moneyWin = playSub.getMoney() + (doubleValue * 20);
//                    playSub.setMoney(moneyWin);
//                    resultJTextArea.setText("Card equals! you won 20 times your bet!" + "\n" + playSub.toString());
//                } else if (isSameNumbers(currentIndex1, currentIndex2)) {
//                    moneyWin = playSub.getMoney() + (doubleValue * 16);
//                    playSub.setMoney(moneyWin);
//                    resultJTextArea.setText("Same numeric ! you won 16 times your bet!" + "\n" + playSub.toString());
//
//                } else if (isSameSuit(currentIndex1, currentIndex2)) {
//                    // Same suit *3
//                    moneyWin = playSub.getMoney() + (doubleValue * 3);
//                    playSub.setMoney(moneyWin);
//                    resultJTextArea.setText("Same suit! you won 3 times your bet!" + "\n" + playSub.toString());
//                } else {
//                    // When nothing matches, subtract the bet amount
//                    moneyWin = moneysub - doubleValue;
//                    playSub.setMoney(moneyWin);
//                    resultJTextArea.setText("Try again! Bet amount deducted from your balance." + "\n" + playSub.toString());
//                }
//                if (moneyWin <= 0) {
//                    moneyWin = 0;
//                    playSub.setMoney(moneyWin);
//                }
//
//                
//
//                // Update player's money
//              
//                Play_it.add(playSub);
//
//                System.out.println(playSub);
//                writeFile(filename);
//                break;
//                
//            }
           
}


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        //change the bet to the bank roll or such. 
        
        
        
        
//        
//          String selectedPlayerName = playerJList.getSelectedValue();
//        Player currentPlayer = searchPlayer(selectedPlayerName);
//        
//        double balance = findName.getSelectedValue();
        
        // Read bet input
        String betString = betJTextField.getText();
        
        // Make sure betString is a double
        try
        {
            betMoney = Double.parseDouble(betString);
        }
        catch (NumberFormatException e)
        {
            String error = "Please enter a valid amount";
            JOptionPane.showMessageDialog(null, error, "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Make sure bet has the right value
        if (betMoney > betMoney) { //theres errors
            String error = "Bet should be less or equal to current balance";
            JOptionPane.showMessageDialog(null, error, "Error", JOptionPane.WARNING_MESSAGE);
            return;   
        }
        
        clearJButton.setEnabled(true);
        myDeck = new DeckOfCards();
        

        double newBalance;
        
        if (cardValue[0] > 10 && cardValue[0] == cardValue[1])
        {
            // If face card and both are the same (ex. Jack, Jack)
            newBalance = balance + ODDS_SAME_FACE * bet;
            resultJTextArea.setText("Both are the same face!\n" + 
                            "You WON " + ODDS_SAME_FACE + " times the bet "
                            + currentPlayer.getName() + ".\nCurrent balance = " + 
                            newBalance);
        }
        else if (cardValue[0] > 10 && cardValue[1] > 10)
        {
            // If they are face cards (ex. Jack, Queen)
            newBalance = balance + ODDS_BOTH_FACE * bet;
            resultJTextArea.setText("Both are face cards!\n" + 
                            "You WON " + ODDS_BOTH_FACE + " times the bet "
                            + currentPlayer.getName() + ".\nCurrent balance = " + 
                            newBalance);
        }
        else if (cardValue[0] == cardValue[1])
        {
            // If they are the same (ex. 3, 3)
            newBalance = balance + ODDS_SAME_CARD * bet;
            resultJTextArea.setText("Both cards are the same!\n" + 
                            "You WON " + ODDS_SAME_CARD + " times the bet "
                            + currentPlayer.getName() + ".\nCurrent balance = " + 
                            newBalance);
        }
        // if both cards are (1 - 13, or 
        else if ((cards[0]-1) / 13 == (cards[1]-1) / 13)
        {
            // If they are the same suit (ex. heart, heart)
            newBalance = balance + ODDS_SAME_SUIT * bet;
            resultJTextArea.setText("Both are the same suit!\n" + 
                            "You WON " + ODDS_SAME_SUIT + " times the bet "
                            + currentPlayer.getName() + ".\nCurrent balance = " + 
                            newBalance);
        }
        else 
        {
            // Lost the bet
            newBalance = balance - betMoney;
            resultJTextArea.setText("You lost the bet" + ".\nCurrent balance = " + 
                            newBalance);
        }
        
        currentPlayer.setBalance(newBalance);
        
        // save the currentPlayer to file
     // Update player's money
              
                Play_it.add(playSub);

                System.out.println(playSub);
                writeFile(filename);
                break;


    }//GEN-LAST:event_drawCardJButtonActionPerformed
    public static int generateRandomNumber() {
        // Create a Random object
        Random random = new Random();

        // Generate a random number between 1 and 52 (inclusive)
        return random.nextInt(52) + 1;
    }
    private void stopMusicJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopMusicJButtonActionPerformed
        clip.stop();
    }//GEN-LAST:event_stopMusicJButtonActionPerformed

    public boolean isSameNumbers(int one, int two) {
//        int count = 1;
        boolean valid = false;
//        if (one > 13 && two > 13) {
//            one = one / 13;
//            one = one % 13;
//            two = two / 13;
//            two = two % 13;
//        }
//        else 
//                {
                    one = one%13;
                    two = two%13;
               // }

        if (one == two) {
            valid = true;
        }

        return valid;
    }

    public boolean isSameSuit(int one, int two) {
        boolean same = false;
        if(one <= 13 && two <=13)
            same = true;
        else if (one > 13 && one <= 26 && two >13 && two <= 26)
            same = true;
        else if (one > 26 && one <= 39 && two > 26 && two <= 39)
            same = true;
        else if ( one > 40 && one <= 52 && two > 39 && two <=52)
            same = true;
        else
            same = false;
        return same;
    }
    private void pMusicJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pMusicJButtonActionPerformed
        playBackgroundMusic();
    }//GEN-LAST:event_pMusicJButtonActionPerformed
    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       showCityData()
     * Description  Display information about the selected city.
     * @param       index int
     * @author      <i>Quynh</i>
     * Date 22/9/2023 History Log 20/9/2023 21/9/2023 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void showCityData(int index) {
        if (index >= 0 && index < Play_it.size()) {
            Players city = Play_it.toArray(new Players[0])[index]; // Convert TreeSet to array to get element by index

            // Assuming you have a UI component where you want to display the data, let's call it cityInfoTextView
            // Replace cityInfoTextView with the actual UI component you want to update
            // Assuming getName(), getAge(), and getMoney() are methods in your City class
            String cityName = city.getName();
            String age = String.valueOf(city.getAge());
            String money = "$" + NumberFormat.getInstance().format(city.getMoney());

            // playerJList.addELement( playerName );
        }
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          findCity()
     * Description     Search for a city by name and return the city obj if found.
     * @param          cityname String
     * @author         <i>Quynh</i>
     * Date 5/10/23
     * @return city History Log 5/10/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void findCity(String playerName) {

        Players dummyPlayer = new Players(playerName);

        // Initialize an index counter
        int index = 0;

        // Iterate through the TreeSet
        for (Players player : Play_it) {
            if (player.getName().equalsIgnoreCase(playerName)) {
                System.out.println("Found");
                System.out.println("Player Name: " + player.getName());

                // Set the selected index in the JList
                playerJList.setSelectedIndex(index);
                return; // Exit the method once found
            }

            //Increment the index for the next iteration
            index++;
        }

        System.out.println("Not Found");
        // Player not found
        JOptionPane.showMessageDialog(null, "Player " + playerName + " not Found",
                "Search Result", JOptionPane.WARNING_MESSAGE);
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          cityExist()
     * Description     Determine of city passed in parameter exist
     * @param          metropolis City
     * @author         <i>Quynh</i>
     * Date 5/10/23
     * @return true or false boolean. History Log 5/10/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private boolean playerExists(Players metropolis) {
        return Play_it.contains(metropolis);
    }
//    private boolean playerExists(Players metropolis)
//    {
//        boolean thereIsOne = false;
//        for(int index = 0; index < Play_it.size() && !thereIsOne; index++)
//        {
//            if(Play_it.get(index).equals(metropolis))
//                thereIsOne = true;
//        }
//        return thereIsOne;
//    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          searchCity()
     * Description     Search for a city by name and highlight if found.
     * @param          cityName String
     * @author         <i>Quynh</i>
     * Date 3/10/23 History Log
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
//    private void searchPlayer(String playerName)
//    {
//        if((playerName != null) && (playerName.length()>0))
//            //check for validation if user enter smt wrong
//        { 
//            //sort the Jlist of city name by name
//          //  nameJRadioButtonMenuItem.setSelected(true);
//            displayPlayers();
//            
//            //Create a String array of city names
//            String[] cityArray = new String[Play_it.size()];
//            for(int i = 0; i < cityArray.length; i++)
//                cityArray[i] = Play_it.get(i).getName().toLowerCase();   
//            //coppying only name to the lower case, copy one by one
//            
//            //find the index of the city that we want to find
//            //find the index of city
//            int index = linearSearch(cityArray, playerName.toLowerCase());
//            //it require the array ans which city do you want to seach for(lower case)
//            if(index < 0)
//                //-1 mean that city is not found
//            {
//                JOptionPane.showMessageDialog(null, "City " + playerName +
//                        " not Found", "Search Refult", JOptionPane.WARNING_MESSAGE);
//                playerJList.setSelectedIndex(0);
//                //not ound then just highlight the one at 0. 
//            }
//            else
//                //show the city, highlight that city
//            {
//                playerJList.setSelectedIndex(index);
//            }
//        }
//    }
    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          linearSearch()
     * Description     Event handler to search city by name using the linear
     *                 search algorithms and to display its index if it found
     *                 and -1 if not found.
     * @return         index int
     * @param cityArray String[]
     * @param cityName String
     * @author         <i>Quynh</i>
     * Date 3/10/23 History Log
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private int linearSearch(String[] cityArray, String cityName) {
        //the parameter taking in the array and the key that you want to find (playerName)
        int index = -1;
        boolean found = false;
        for (int i = 0; i < cityArray.length && !found; i++) //go in the loop as long as it not right ( true)
        {
            if (cityArray[i].toLowerCase().contains(cityName.toLowerCase())) //WHy lower case again? if you need a snipe of that code, just
            //grab it and paste to your other project. 
            //if it contain ( found them then) found become true and return 0.
            {
                index = i;
                found = true;
            }
        }
        return index;
        //linearSearch is pretty slow if you have large database. 
    }

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method          binarySearch()
     * Description     Search by city using the binary search method.
     *                 Return -1 if city is not found.
     * @return         middle int, index of where city is found
     * @param array String[]
     * @param key String
     * @author         <i>Quynh</i>
     * Date 3/10/23 History Log
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    // more efficent but require the database to be sorted. 
    public static int binarySearch(String[] array, String key) {
        int low = 0;
        int high = array.length - 1;
        int middle;
        while (low <= high) {
            middle = (low + high) / 2;
            if (key.equalsIgnoreCase(array[middle])) //exact match
            //            if(array[middle].contains(key)) partial match does not work
            {
                return middle;
            } //middle is when it founded. 
            else if (key.compareToIgnoreCase(array[middle]) < 0) {
                high = middle - 1;
            } else {
                low = middle + 1;
            }
            //cutting the array by changing the low, high.
        }
        return -1;       //when the search key is not found

    }
    //In this program we using the linearSearch but the Binary is worth to look at. 
    //because binary required WHOLE THIng to be typed in. 

    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method        writeFile()
     * Description   Write cities to a text file that is comma delimited
     * @param        file String
     * @author       <i>Quynh Le</i>
     * Date 2/10/2023 History Log
     * @see java.io.FileWriter
     * @see java.io.PrintWriter
     * @see City
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    private void writeFile(String file) {
        try {
            FileWriter filePointer = new FileWriter(filename, false); //line that would rewrite to file
            PrintWriter output = new PrintWriter(filePointer);

            for (Players tempCity : Play_it) {
                String line = tempCity.getName() + ","
                        + tempCity.getAge() + "," + tempCity.getMoney();

                output.write(line + "\n");
            }

            output.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null,
                    "Player not saved", "Save error", JOptionPane.WARNING_MESSAGE);

            playerJList.setVisible(true);
            playerJList.setSelectedIndex(0);
        }
    }

//    private void saveCities(String file)
//    {
//        try
//        {
//            FileWriter filePointer = new FileWriter(file, false);
//            //You pass on the file into the object, when the 2nd one if true mean
//            //that you will add on into the program, false is replace (?). 
//            PrintWriter output = new PrintWriter(filePointer);
//            for(int index = 0; index < Play_it.size(); index++)
//            {
//                Players tempCity = Play_it.get(index);
//                String line = tempCity.getName() + "," + 
//                        tempCity.getAge() + "," + tempCity.getMoney();
//                //We're taking in new infromation and details about the tempcity 
//                //Do not add an extra blank line to end of file
//                if(index == Play_it.size() -1)
//                    //So this code, every time end of the line we jumping to a 
//                    //new line like 12.0 in boston and goes to new line fill in Chicago.
//                    output.write(line);
//                else
//                    output.write(line + "\n");
//               
//            }
//           output.close();
//        }
//        catch (IOException ex)
//        {
//            JOptionPane.showMessageDialog(null,
//                    "City not saved", "Save error", JOptionPane.WARNING_MESSAGE);
//            //Tell them that there's some errors
//            //set the lsit to be visible
//            playerJList.setVisible(true);
//            playerJList.setSelectedIndex(0);
//        }
//    }
    /**
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method        main()
     * Description   Call the contructor to create an instance of the form
     * @param        args are the command line strings
     * @author       <i>Quynh Le</i>
     * Date 9/20/23 History Log 20/9/2023, 21/9/2023, 22/9/2023
     * </pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     */
    public static void main(String args[]) {
        Splash mySplash = new Splash(5000); // duration = 4 seconds
        mySplash.showSplash(); // show splash screen

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                try {
                    new CardGameGUI().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(CardGameGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("CardGameGUI instance created. Making it visible...");
                // cardGameGUI.setVisible(true);

            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutJMenuItem;
    private javax.swing.JMenu actionJMendatabaseJMenuu;
    private javax.swing.JMenuItem addJMenuItem;
    private javax.swing.JTextField betJTextField;
    private javax.swing.JLabel card1JLabel;
    private javax.swing.JLabel card2JLabel;
    private javax.swing.JMenuBar cardJMenuBar;
    private javax.swing.JButton clearJButton;
    private javax.swing.JMenuItem deleteJMenuItem;
    private javax.swing.JButton drawCardJButton;
    private javax.swing.JButton exitJButton;
    private javax.swing.JMenuItem exitJMenuItem;
    private javax.swing.JMenu fileJMenu;
    private javax.swing.JPopupMenu.Separator fileJSeparator;
    private javax.swing.JMenu helpJMenu;
    private javax.swing.JTextArea instructorJTextArea;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JMenuItem newJMenuItem;
    private javax.swing.JButton pMusicJButton;
    private javax.swing.JList<String> playerJList;
    private javax.swing.JLabel playerTittleJLabel;
    private javax.swing.JMenuItem printPlayerFormJMenuItem;
    private javax.swing.JMenuItem printPlayerJMenuItem;
    private javax.swing.JTextArea resultJTextArea;
    private javax.swing.JScrollPane resultJTextAreaS;
    private javax.swing.JMenuItem savePlayerJMenuItem;
    private javax.swing.JMenuItem searchJMenuItem;
    private javax.swing.ButtonGroup sortButtonGroup;
    private javax.swing.JButton stopMusicJButton;
    private javax.swing.JLabel titleJLabel;
    private javax.swing.JPanel titleJPanel;
    // End of variables declaration//GEN-END:variables

    /*Splash screen is like: right click on the Large USA Cities StartUp ( the 
    coffee cup). And then click on the properties, click on Run. put in:
    -splash:src/USACities/buckinghamfountain.jpg the path where you can find it. 
    // End of variables declaration 
    Please note that your filename and yoru teacher fileName isn't the same. if 
    there's error then prob that you're using wrong upper.
    
    putting progress bar and percentage. 
    setModal(true); mean that they're not going to pop back if you didnt finish with recent window. 
    
     */
}
