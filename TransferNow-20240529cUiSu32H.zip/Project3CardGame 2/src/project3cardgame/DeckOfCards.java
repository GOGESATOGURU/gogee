package project3cardgame;

import java.util.ArrayList;
import java.util.Collections;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*<pre>>
* Class           DeckOfCards
* File name       DeckOfCards.java
* Description     Two Cards Game
* Platform        jdk 1.8.0_214, NetBeans IDE IOS
* Course          CS 142
* Hours           1 hour and 45 minutes
* Date            11/12/2023
* History log  
* @author         <i>Quynh Le</i>
* @version %      1.5.0
* @see            javax.swing.JFrame
* </pre>
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class DeckOfCards 
{
    // Instance variables
    final int FULL_DECK_SIZE = 52;
    private ArrayList<Integer> cardDeck = new ArrayList<>();   //index 0-51 with values 1-52
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Constructor     DeckOfCards()-default constructor
     * Description     Creates a new deck of cards
     * @author         <i>Quynh Le</i>
     * Date            11/12/2023
     * History Log    
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public DeckOfCards()
    {
        // Create an arrayList of cards with values 1-52
        for (int i = 1; i <= FULL_DECK_SIZE; i++)
        {
            cardDeck.add(i);
        }    
    }   
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method          getRandomCard() 
     * Description     Returns a random card index and removes the index
     *                 cardDeck ArrayList so it will not be used again
     * @author         <i>Quynh Le</i>
     * Date            11/17/2023
     * History Log     
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public int getRandomCard()
    {
        int randomIndex = (int) (Math.random() * cardDeck.size());
        int card = cardDeck.get(randomIndex);
        cardDeck.remove(randomIndex);
        return card;
    } 
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method          getRandomSuit() 
     * Description     Event handler to get a random suit
     * @author         <i>Quynh Le</i>
     * Date            11/17/2023
     * History Log     
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public int getRandomSuit()
    {
        return (int) (Math.random() * 4) + 1;
    }     
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method          putCardDeck() 
     * Description     Event handler to put cards back in the deck
     * @author         <i>Quynh Le</i>
     * @param          card int
     * Date            11/17/2023
     * History Log     
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void putCardDeck(int card)
    {
        cardDeck.add(card);
    }    

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method          isCardDeck() 
     * Description     Returns true if card is in the deck
     * @author         <i>Quynh Le</i>
     * @param          card int
     * Date            11/17/2023
     * History Log     
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/    
     public boolean isCardDeck(int card)
     {
         return cardDeck.contains(card);
     }    
     
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method          shuffle() 
     * Description     Event handler to shuffle if wanted
     * @author         <i>Quynh Le</i>
     * Date            11/17/2023
     * History Log     
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public void shuffle()
    {
        Collections.shuffle(cardDeck);
    }        
     
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method          toString() 
     * Description     Event handler for Override toString method
     * @author         <i>Quynh Le</i>
     * Date            11/17/2023
     * History Log     
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public String toString()
    {
        return "DeckOfCards{" + "cardDeck=" + cardDeck + '}';
    }  

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method          equals() 
     * Description     Event handler for Override equals method
     * @author         <i>Quynh Le</i>
     * @param          obj Object
     * Date            11/17/2023
     * History Log     
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/    
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        DeckOfCards that = (DeckOfCards) obj;
        return cardDeck.equals(that.cardDeck);
        
    }        
       
}

